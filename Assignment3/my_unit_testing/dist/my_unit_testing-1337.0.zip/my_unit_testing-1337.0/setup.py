from distutils.core import setup
setup(name='my_unit_testing',
      version='1337.0',
      py_modules=['addition_testing','my_unit_testing'],
      description='Skoleoppgave test som feiler',
      author='Erlend Westbye',
      author_email='erlendwestbye@gmail.com',
      url='https://github.com/erlendw',
      )