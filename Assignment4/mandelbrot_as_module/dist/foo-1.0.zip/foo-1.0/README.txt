this is the read me for this package

You can rebuild this package by using python setup.py sdist

https://docs.python.org/2/distutils/introduction.html#distutils-simple-example
